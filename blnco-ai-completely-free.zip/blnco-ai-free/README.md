# BLNCO AI — completely free starter

This is a static website. It has **no paid API, no API key, no Replit dependency, and no subscription requirement**.

## Included
- Responsive black, white and gold dashboard
- Editable projects and notes, saved in this browser using local storage
- Create, rename, duplicate, delete and export projects
- Export all projects as a JSON backup
- ChatGPT handoff: prepare a BLNCO AI prompt, copy it, then open ChatGPT and paste it
- Optional browser voice dictation where supported

## Important limits
- The ChatGPT handoff opens ChatGPT separately. It does not provide automatic AI chat inside this website.
- ChatGPT use is subject to the user's existing ChatGPT access and limits. This website does not create API charges.
- Projects stay in the browser/device where they were created. They do not automatically sync between iPhone and desktop. Use **Export all** to back up and move the JSON file.
- This is a starter workspace, not yet a video/audio editor or Twitch-connected bot.

## Free hosting with GitHub Pages (iPhone-friendly)
1. Download and unzip `blnco-ai-free.zip` in the iPhone Files app.
2. In Safari, sign in or create a free account at https://github.com.
3. Create a new **public** repository named `blnco-ai`.
4. Open the repository and choose **Add file → Upload files**.
5. Upload `index.html`, `styles.css`, `app.js`, and `manifest.webmanifest` from the unzipped folder. You can also upload this README.
6. Commit the files to the repository's `main` branch.
7. Open the repository **Settings → Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
9. Wait for GitHub Pages to publish. Your site address will look like `https://YOUR-USERNAME.github.io/blnco-ai/`.

GitHub may change its menus. If you cannot find a step, use GitHub's official Pages guide: https://docs.github.com/en/pages/quickstart

## Add to iPhone Home Screen
Open your published site in Safari → Share → **Add to Home Screen**.

## Keep your work safe
Use Projects → **Export all** regularly. Clearing Safari website data or using private browsing can remove local projects. Keep the exported JSON backup somewhere safe.
